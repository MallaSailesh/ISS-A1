# ISS Assignment 1 
# Name : Malla Sailesh
# Roll Number : 2021101106 

## very important :- dont take 1.txt 2.txt as input files because i aldready took them as my temporary files</br>
</br>

### All the programs are were tested on BASH in ubunut 20.04

## To give permissions to all shell programs 
chmod 755 *.sh

# Question1 </br>
for executing :- ./Q1.sh </br></br>

# Question2 </br>
for executing :- ./Q2.sh </br></br>

# Question3 </br>
for executing :- ./Q3.sh 
## for this i printed the output on to the terminal and also stored the ouputs in the respective files for 3d and 3e</br></br>

# Question4 </br>
for executing :- ./Q4.sh </br></br>

# Question5 </br>
for executing :- ./Q5.sh 
## very important :- for the three parts i took only one input so take the input such that it contain even number of characters in the string </br></br>

